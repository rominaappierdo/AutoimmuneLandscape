This directory contains the final annotated dataset
